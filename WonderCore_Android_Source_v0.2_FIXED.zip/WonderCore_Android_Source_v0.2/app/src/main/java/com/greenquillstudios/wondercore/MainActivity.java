package com.greenquillstudios.wondercore;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(48, 48, 48, 48);
        page.setBackgroundColor(Color.rgb(7, 10, 24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.greenquillstudios.wondercore.R.mipmap.ic_launcher);
        page.addView(logo, new LinearLayout.LayoutParams(360, 360));

        TextView title = new TextView(this);
        title.setText("WONDERCORE");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        page.addView(title);

        TextView tagline = new TextView(this);
        tagline.setText("BUILD  •  CREATE  •  IMAGINE");
        tagline.setTextColor(Color.rgb(0, 229, 255));
        tagline.setTextSize(16);
        tagline.setGravity(Gravity.CENTER);
        tagline.setPadding(0, 20, 0, 0);
        page.addView(tagline);

        TextView status = new TextView(this);
        status.setText("\nQuill Studio mobile foundation is installed and ready.");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        page.addView(status);

        setContentView(page);
    }
}
