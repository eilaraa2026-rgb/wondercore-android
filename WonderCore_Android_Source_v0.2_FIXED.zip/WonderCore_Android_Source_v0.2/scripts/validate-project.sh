#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="${1:-.}"
cd "$PROJECT_ROOT"
missing=()
warnings=()
require_file(){ [[ -f "$1" ]] || missing+=("$1"); }
require_dir(){ [[ -d "$1" ]] || missing+=("$1/"); }
require_one_of(){ local label="$1"; shift; for p in "$@"; do [[ -f "$p" ]] && return 0; done; missing+=("$label"); }
echo "WonderCore Build Doctor"
echo "Project root: $(pwd)"
echo
require_file "gradlew"
require_file "gradle/wrapper/gradle-wrapper.jar"
require_file "gradle/wrapper/gradle-wrapper.properties"
require_dir "app"
require_file "app/src/main/AndroidManifest.xml"
require_one_of "settings.gradle or settings.gradle.kts" "settings.gradle" "settings.gradle.kts"
require_one_of "build.gradle or build.gradle.kts" "build.gradle" "build.gradle.kts"
require_one_of "app/build.gradle or app/build.gradle.kts" "app/build.gradle" "app/build.gradle.kts"
[[ -x gradlew ]] || warnings+=("gradlew exists but is not executable; the workflow will fix this automatically.")
grep -q 'android.intent.action.MAIN' app/src/main/AndroidManifest.xml || missing+=("MAIN launcher intent")
grep -q 'android.intent.category.LAUNCHER' app/src/main/AndroidManifest.xml || missing+=("LAUNCHER category")
grep -Eq 'applicationId[[:space:]]+["'"']' app/build.gradle* || warnings+=("No applicationId declaration was detected.")
if (( ${#missing[@]} )); then
  echo "BUILD STOPPED"
  printf ' - %s\n' "${missing[@]}"
  exit 1
fi
echo "PASS: All required Android project files are present."
if (( ${#warnings[@]} )); then
  echo "Warnings:"
  printf ' - %s\n' "${warnings[@]}"
fi
echo "Build Doctor completed successfully."
