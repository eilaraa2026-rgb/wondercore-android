WONDERCORE ANDROID v0.2

This package repairs the prior tiny/invalid APK build and adds:
- Unique package ID: com.greenquillstudios.wondercore
- Version code 2 / version 0.2
- Launcher activity
- WonderCore neon app icon
- Functional medium home-screen widget
- Build Doctor validation
- APK minimum-size validation
- Trusted Gradle Wrapper regeneration in GitHub Actions

PHONE BUILD:
1. Upload this ZIP to the root of the GitHub repository.
2. Keep .github/workflows/build-android.yml in the repository.
3. Commit the upload.
4. Open Actions > WonderCore Mobile APK Build.
5. Download WonderCore-v0.2-debug-APK.
6. Unzip the artifact and install WonderCore-v0.2-debug.apk.

If Android reports a package conflict, uninstall the earlier test app first.
