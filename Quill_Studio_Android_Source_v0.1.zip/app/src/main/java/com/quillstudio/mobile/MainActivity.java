package com.quillstudio.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 41;
    private SpectrumView spectrumView;
    private TextView status;
    private Button monitorButton;
    private Button recordButton;
    private AudioEngine audioEngine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(8, 10, 15));

        TextView title = new TextView(this);
        title.setText("QUILL STUDIO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Android-native vocal studio • v0.1");
        subtitle.setTextColor(Color.rgb(160, 170, 190));
        subtitle.setTextSize(14f);
        root.addView(subtitle);

        spectrumView = new SpectrumView(this);
        LinearLayout.LayoutParams spectrumParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        spectrumParams.setMargins(0, 28, 0, 22);
        root.addView(spectrumView, spectrumParams);

        status = new TextView(this);
        status.setText("Ready. Allow microphone access, then start monitoring.");
        status.setTextColor(Color.rgb(210, 215, 225));
        status.setTextSize(14f);
        status.setPadding(0, 0, 0, 18);
        root.addView(status);

        monitorButton = new Button(this);
        monitorButton.setText("START LIVE ANALYZER");
        root.addView(monitorButton);

        recordButton = new Button(this);
        recordButton.setText("RECORD WAV");
        recordButton.setEnabled(false);
        root.addView(recordButton);

        TextView note = new TextView(this);
        note.setText("Recordings are saved inside the app's Music folder.");
        note.setTextColor(Color.rgb(125, 135, 155));
        note.setTextSize(12f);
        note.setPadding(0, 16, 0, 0);
        root.addView(note);

        setContentView(root);

        audioEngine = new AudioEngine();

        monitorButton.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                return;
            }
            toggleMonitor();
        });

        recordButton.setOnClickListener(v -> toggleRecord());
    }

    private void toggleMonitor() {
        if (!audioEngine.isRunning()) {
            try {
                audioEngine.start();
                monitorButton.setText("STOP LIVE ANALYZER");
                recordButton.setEnabled(true);
                status.setText("Listening through the phone microphone.");
            } catch (Exception e) {
                status.setText("Could not start microphone: " + e.getMessage());
            }
        } else {
            audioEngine.stop();
            monitorButton.setText("START LIVE ANALYZER");
            recordButton.setText("RECORD WAV");
            recordButton.setEnabled(false);
            status.setText("Analyzer stopped.");
        }
    }

    private void toggleRecord() {
        if (!audioEngine.isRecording()) {
            try {
                File file = audioEngine.startRecording();
                recordButton.setText("STOP & SAVE WAV");
                status.setText("Recording: " + file.getName());
            } catch (Exception e) {
                status.setText("Could not start recording: " + e.getMessage());
            }
        } else {
            File file = audioEngine.stopRecording();
            recordButton.setText("RECORD WAV");
            status.setText(file == null ? "Recording stopped." :
                    "Saved: " + file.getAbsolutePath());
        }
    }

    @Override
    protected void onDestroy() {
        audioEngine.stop();
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            toggleMonitor();
        } else {
            status.setText("Microphone permission is required.");
        }
    }

    private class AudioEngine {
        private final int sampleRate = 44100;
        private final int fftSize = 2048;
        private final AtomicBoolean running = new AtomicBoolean(false);
        private final AtomicBoolean recording = new AtomicBoolean(false);
        private AudioRecord recorder;
        private Thread worker;
        private ByteArrayOutputStream wavData;
        private File currentFile;

        boolean isRunning() { return running.get(); }
        boolean isRecording() { return recording.get(); }

        void start() {
            int min = AudioRecord.getMinBufferSize(sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            int bufferSize = Math.max(min, fftSize * 2);

            recorder = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .build())
                    .setBufferSizeInBytes(bufferSize)
                    .build();

            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("AudioRecord initialization failed");
            }

            running.set(true);
            recorder.startRecording();
            worker = new Thread(this::loop, "QuillAudioEngine");
            worker.start();
        }

        void stop() {
            running.set(false);
            recording.set(false);
            if (recorder != null) {
                try { recorder.stop(); } catch (Exception ignored) {}
                recorder.release();
                recorder = null;
            }
            if (worker != null) {
                try { worker.join(500); } catch (InterruptedException ignored) {}
                worker = null;
            }
        }

        File startRecording() throws IOException {
            File dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC);
            if (dir == null) throw new IOException("Storage folder unavailable");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create storage folder");

            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            currentFile = new File(dir, "QuillStudio_" + stamp + ".wav");
            wavData = new ByteArrayOutputStream();
            recording.set(true);
            return currentFile;
        }

        File stopRecording() {
            recording.set(false);
            if (currentFile == null || wavData == null) return null;
            try {
                writeWav(currentFile, wavData.toByteArray(), sampleRate, 1, 16);
            } catch (IOException e) {
                runOnUiThread(() -> status.setText("Save failed: " + e.getMessage()));
                return null;
            } finally {
                wavData = null;
            }
            return currentFile;
        }

        private void loop() {
            short[] buffer = new short[fftSize];
            while (running.get()) {
                int count = recorder.read(buffer, 0, buffer.length, AudioRecord.READ_BLOCKING);
                if (count <= 0) continue;

                if (recording.get() && wavData != null) {
                    synchronized (this) {
                        for (int i = 0; i < count; i++) {
                            short s = buffer[i];
                            wavData.write(s & 0xff);
                            wavData.write((s >> 8) & 0xff);
                        }
                    }
                }

                double[] magnitudes = FFT.calculate(buffer, count);
                runOnUiThread(() -> spectrumView.setSpectrum(magnitudes));
            }
        }

        private void writeWav(File file, byte[] pcm, int rate, int channels, int bits)
                throws IOException {
            try (DataOutputStream out = new DataOutputStream(
                    new BufferedOutputStream(new FileOutputStream(file)))) {
                int byteRate = rate * channels * bits / 8;
                writeAscii(out, "RIFF");
                writeLEInt(out, 36 + pcm.length);
                writeAscii(out, "WAVE");
                writeAscii(out, "fmt ");
                writeLEInt(out, 16);
                writeLEShort(out, (short) 1);
                writeLEShort(out, (short) channels);
                writeLEInt(out, rate);
                writeLEInt(out, byteRate);
                writeLEShort(out, (short) (channels * bits / 8));
                writeLEShort(out, (short) bits);
                writeAscii(out, "data");
                writeLEInt(out, pcm.length);
                out.write(pcm);
            }
        }

        private void writeAscii(DataOutputStream out, String s) throws IOException {
            out.writeBytes(s);
        }
        private void writeLEInt(DataOutputStream out, int v) throws IOException {
            out.writeByte(v); out.writeByte(v >> 8); out.writeByte(v >> 16); out.writeByte(v >> 24);
        }
        private void writeLEShort(DataOutputStream out, short v) throws IOException {
            out.writeByte(v); out.writeByte(v >> 8);
        }
    }

    public static class FFT {
        static double[] calculate(short[] input, int count) {
            int n = 1;
            while (n * 2 <= count) n *= 2;
            double[] real = new double[n];
            double[] imag = new double[n];

            for (int i = 0; i < n; i++) {
                double window = 0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / (n - 1));
                real[i] = input[i] * window;
            }

            for (int i = 1, j = 0; i < n; i++) {
                int bit = n >> 1;
                for (; (j & bit) != 0; bit >>= 1) j ^= bit;
                j ^= bit;
                if (i < j) {
                    double tr = real[i]; real[i] = real[j]; real[j] = tr;
                    double ti = imag[i]; imag[i] = imag[j]; imag[j] = ti;
                }
            }

            for (int len = 2; len <= n; len <<= 1) {
                double angle = -2 * Math.PI / len;
                double wLenR = Math.cos(angle);
                double wLenI = Math.sin(angle);
                for (int i = 0; i < n; i += len) {
                    double wr = 1, wi = 0;
                    for (int j = 0; j < len / 2; j++) {
                        int u = i + j;
                        int v = i + j + len / 2;
                        double vr = real[v] * wr - imag[v] * wi;
                        double vi = real[v] * wi + imag[v] * wr;
                        real[v] = real[u] - vr;
                        imag[v] = imag[u] - vi;
                        real[u] += vr;
                        imag[u] += vi;
                        double nextWr = wr * wLenR - wi * wLenI;
                        wi = wr * wLenI + wi * wLenR;
                        wr = nextWr;
                    }
                }
            }

            int bins = 96;
            double[] out = new double[bins];
            for (int b = 0; b < bins; b++) {
                double t0 = b / (double) bins;
                double t1 = (b + 1) / (double) bins;
                int from = Math.max(1, (int) Math.pow(n / 2.0, t0));
                int to = Math.max(from + 1, (int) Math.pow(n / 2.0, t1));
                to = Math.min(to, n / 2);
                double max = 0;
                for (int k = from; k < to; k++) {
                    double mag = Math.hypot(real[k], imag[k]) / n;
                    if (mag > max) max = mag;
                }
                double db = 20.0 * Math.log10(max + 1e-9);
                out[b] = Math.max(0, Math.min(1, (db + 75) / 75.0));
            }
            return out;
        }
    }

    public static class SpectrumView extends View {
        private double[] spectrum = new double[96];
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);

        public SpectrumView(android.content.Context context) {
            super(context);
            paint.setStrokeCap(Paint.Cap.ROUND);
            grid.setColor(Color.rgb(35, 40, 52));
            grid.setStrokeWidth(1f);
        }

        void setSpectrum(double[] values) {
            this.spectrum = values;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(Color.rgb(13, 16, 24));

            int w = getWidth();
            int h = getHeight();
            for (int i = 1; i < 5; i++) {
                float y = h * i / 5f;
                canvas.drawLine(0, y, w, y, grid);
            }

            float gap = 3f;
            float bw = Math.max(2f, (w - gap * spectrum.length) / spectrum.length);
            for (int i = 0; i < spectrum.length; i++) {
                float value = (float) spectrum[i];
                float left = i * (bw + gap);
                float top = h - value * (h - 12);
                float hue = 220f - (200f * i / spectrum.length);
                paint.setColor(Color.HSVToColor(new float[]{hue, 0.9f, 1f}));
                canvas.drawRoundRect(left, top, left + bw, h, bw / 2, bw / 2, paint);
            }
        }
    }
}
