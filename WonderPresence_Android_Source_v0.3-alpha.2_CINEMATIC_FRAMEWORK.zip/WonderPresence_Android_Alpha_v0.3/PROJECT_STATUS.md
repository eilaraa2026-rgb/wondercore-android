# WonderPresence Alpha — Project Status

**Checkpoint:** 7.13  
**Version:** 0.3-alpha.1  
**State:** Build-ready source package

## Canon branding

**Powered by WonderCore™**  
**Featuring WonderPresence™**

## What works in this Alpha

- Android app shell and canonical WonderCore icon.
- Text chat UI for WonderPresence / Quill.
- OpenAI Responses API bridge.
- Multi-turn chaining with `previous_response_id`.
- API key is held in memory only and cleared when the activity is destroyed.
- GitHub Actions can regenerate the Gradle wrapper and build a debug APK from the newest source ZIP.

## Important Alpha limitation

The current developer Alpha asks for an OpenAI API key. This is **not** the intended consumer experience. Production WonderPresence must use a safe account/service bridge so ordinary users never have to understand or paste API keys.

## Canon product direction

- WonderScript is the intended primary language of the WonderVerse; native Android code is a bootstrap/bridge.
- Conversation should remain available while background tasks run.
- UX should expose one obvious next action and hide technical machinery by default.
- User friction and rabbit holes are usability-test evidence.
- Wellbeing/SMS check-ins are opt-in, user-controlled, easy to stop, and must never infer an emergency merely from silence.

## Next step

Upload `WonderCore_Android_Source_v0.3_WONDERPRESENCE_ALPHA_7.13.zip` to the repository root on `main`. The existing GitHub workflow selects the newest matching `WonderCore_Android_Source*.zip`, builds it, and publishes the debug APK artifact.

## 7.13 build-readiness correction

- GitHub Actions now selects the newest `WonderCore_Android_Source*.zip` rather than preferring 7.11.
- Build Doctor now validates the current `WonderPresence Alpha` app name and `0.3-alpha.1` version.
- This removes two false failures that would have prevented 7.12 from reaching `assembleDebug`.
