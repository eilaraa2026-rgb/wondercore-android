#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="${1:-.}"
cd "$PROJECT_ROOT"
missing=()
warnings=()
require_file(){ [[ -f "$1" ]] || missing+=("$1"); }
require_dir(){ [[ -d "$1" ]] || missing+=("$1/"); }
require_one_of(){ local label="$1"; shift; for p in "$@"; do [[ -f "$p" ]] && return 0; done; missing+=("$label"); }

echo "WonderPresence Build Doctor — ALPHA 7.13"
echo "Project root: $(pwd)"
echo

require_file "gradlew"
require_file "gradle/wrapper/gradle-wrapper.jar"
require_file "gradle/wrapper/gradle-wrapper.properties"
require_dir "app"
require_file "app/src/main/AndroidManifest.xml"
require_file "app/src/main/res/values/strings.xml"
require_file "app/src/main/java/com/greenquillstudios/wondercore/MainActivity.java"
require_one_of "settings.gradle or settings.gradle.kts" "settings.gradle" "settings.gradle.kts"
require_one_of "build.gradle or build.gradle.kts" "build.gradle" "build.gradle.kts"
require_one_of "app/build.gradle or app/build.gradle.kts" "app/build.gradle" "app/build.gradle.kts"

[[ -x gradlew ]] || warnings+=("gradlew exists but is not executable; the workflow fixes this automatically.")
grep -q 'android.intent.action.MAIN' app/src/main/AndroidManifest.xml || missing+=("MAIN launcher intent")
grep -q 'android.intent.category.LAUNCHER' app/src/main/AndroidManifest.xml || missing+=("LAUNCHER category")
grep -q 'android.permission.INTERNET' app/src/main/AndroidManifest.xml || missing+=("INTERNET permission")
grep -Eq "applicationId[[:space:]]+" app/build.gradle* || warnings+=("No applicationId declaration was detected.")
grep -q '<string name="app_name">WonderPresence Alpha</string>' app/src/main/res/values/strings.xml || missing+=("canonical app_name = WonderPresence Alpha")
grep -q 'WonderPresence Alpha' app/src/main/java/com/greenquillstudios/wondercore/MainActivity.java || missing+=("WonderPresence Alpha UI")
grep -q 'https://api.openai.com/v1/responses' app/src/main/java/com/greenquillstudios/wondercore/MainActivity.java || missing+=("OpenAI Responses API bridge")
grep -q "versionName '0.3-alpha.1'" app/build.gradle || missing+=("versionName 0.3-alpha.1")

# A real Gradle wrapper JAR is a ZIP/JAR and begins with the PK signature.
# The package carries a bootstrap marker; the GitHub workflow must regenerate it before this doctor runs.
if [[ -f gradle/wrapper/gradle-wrapper.jar ]]; then
  sig="$(od -An -tx1 -N2 gradle/wrapper/gradle-wrapper.jar 2>/dev/null | tr -d ' \n')"
  if [[ "$sig" != "504b" ]]; then
    missing+=("trusted Gradle wrapper JAR (workflow regeneration did not occur)")
  fi
fi

if (( ${#missing[@]} )); then
  echo "BUILD STOPPED"
  printf ' - %s\n' "${missing[@]}"
  exit 1
fi

echo "PASS: Android project, Alpha chat bridge, and canonical branding checks passed."
if (( ${#warnings[@]} )); then
  echo "Warnings:"
  printf ' - %s\n' "${warnings[@]}"
fi
echo "Build Doctor completed successfully."
