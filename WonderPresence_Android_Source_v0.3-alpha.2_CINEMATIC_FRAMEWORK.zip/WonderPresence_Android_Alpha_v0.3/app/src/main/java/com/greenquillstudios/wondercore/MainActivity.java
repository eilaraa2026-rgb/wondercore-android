package com.greenquillstudios.wondercore;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String API_URL = "https://api.openai.com/v1/responses";
    private static final String MODEL = "gpt-5.1";
    private static final String INSTRUCTIONS =
            "You are Quill, the WonderPresence Alpha companion, powered by WonderCore. " +
            "Be warm, capable, concise, collaborative, and practical. Address the user as a trusted creative partner. " +
            "WonderCore is the user's creator platform; WonderPresence is its companion layer. " +
            "WonderScript is the long-term user-facing language while native Android code is the bootstrap/bridge. " +
            "Do not pretend this API session has access to the user's ChatGPT account, private memory, files, or prior chats unless the user provides that context in this conversation.";

    private String apiKey = "";
    private String previousResponseId = null;

    private LinearLayout root;
    private LinearLayout connectPanel;
    private LinearLayout chatPanel;
    private EditText keyInput;
    private EditText messageInput;
    private TextView transcript;
    private TextView status;
    private Button sendButton;
    private ScrollView transcriptScroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private TextView makeText(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        return v;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(7, 10, 24));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(58), dp(58));
        logoParams.setMargins(0, 0, dp(14), 0);
        header.addView(logo, logoParams);

        LinearLayout headerText = new LinearLayout(this);
        headerText.setOrientation(LinearLayout.VERTICAL);
        TextView title = makeText("WonderPresence Alpha", 24, Color.WHITE);
        TextView subtitle = makeText("Powered by WonderCore™ • Featuring WonderPresence™", 13, Color.rgb(196, 204, 214));
        headerText.addView(title);
        headerText.addView(subtitle);
        header.addView(headerText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(header);

        status = makeText("Not connected", 13, Color.rgb(255, 193, 7));
        status.setPadding(0, dp(10), 0, dp(10));
        root.addView(status);

        Button settings = new Button(this);
        settings.setText("INTRO SETTINGS");
        settings.setOnClickListener(v -> showIntroSettings());
        root.addView(settings);

        buildConnectPanel();
        buildChatPanel();

        setContentView(root);
    }

    private void buildConnectPanel() {
        connectPanel = new LinearLayout(this);
        connectPanel.setOrientation(LinearLayout.VERTICAL);
        connectPanel.setPadding(0, dp(12), 0, 0);

        TextView intro = makeText(
                "Developer Alpha setup\nPaste an OpenAI API key for this session. WonderPresence holds it only in memory and does not save it to the phone.",
                15, Color.LTGRAY);
        intro.setLineSpacing(0, 1.15f);
        connectPanel.addView(intro);

        keyInput = new EditText(this);
        keyInput.setHint("sk-… API key");
        keyInput.setHintTextColor(Color.rgb(120, 130, 145));
        keyInput.setTextColor(Color.WHITE);
        keyInput.setSingleLine(true);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
        LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        keyParams.setMargins(0, dp(12), 0, dp(10));
        connectPanel.addView(keyInput, keyParams);

        Button connect = new Button(this);
        connect.setText("CONNECT QUILL");
        connect.setOnClickListener(v -> connect());
        connectPanel.addView(connect);

        TextView note = makeText(
                "This Alpha uses the OpenAI API, which is separate from a ChatGPT Plus subscription and does not automatically inherit this ChatGPT conversation or memories.",
                12, Color.rgb(155, 164, 178));
        note.setPadding(0, dp(12), 0, 0);
        connectPanel.addView(note);

        root.addView(connectPanel);
    }

    private void buildChatPanel() {
        chatPanel = new LinearLayout(this);
        chatPanel.setOrientation(LinearLayout.VERTICAL);
        chatPanel.setVisibility(View.GONE);

        transcript = makeText("Quill: Connection ready. Say hello, mate.\n", 16, Color.WHITE);
        transcript.setTextIsSelectable(true);
        transcript.setPadding(dp(12), dp(12), dp(12), dp(12));

        transcriptScroll = new ScrollView(this);
        transcriptScroll.setFillViewport(true);
        transcriptScroll.addView(transcript);
        chatPanel.addView(transcriptScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        messageInput = new EditText(this);
        messageInput.setHint("Message Quill…");
        messageInput.setHintTextColor(Color.rgb(120, 130, 145));
        messageInput.setTextColor(Color.WHITE);
        messageInput.setMinLines(1);
        messageInput.setMaxLines(5);
        messageInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        chatPanel.addView(messageInput);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.END);

        Button reset = new Button(this);
        reset.setText("NEW CHAT");
        reset.setOnClickListener(v -> resetConversation());
        buttons.addView(reset);

        sendButton = new Button(this);
        sendButton.setText("SEND");
        sendButton.setOnClickListener(v -> sendMessage());
        buttons.addView(sendButton);
        chatPanel.addView(buttons);

        root.addView(chatPanel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
    }

    private void connect() {
        String candidate = keyInput.getText().toString().trim();
        if (candidate.length() < 20) {
            Toast.makeText(this, "Enter a valid OpenAI API key.", Toast.LENGTH_SHORT).show();
            return;
        }
        apiKey = candidate;
        keyInput.setText("");
        previousResponseId = null;
        connectPanel.setVisibility(View.GONE);
        chatPanel.setVisibility(View.VISIBLE);
        status.setText("Connected • " + MODEL + " • key held in memory only");
        status.setTextColor(Color.rgb(92, 214, 138));
        messageInput.requestFocus();
    }

    private void resetConversation() {
        previousResponseId = null;
        transcript.setText("Quill: Fresh thread ready. What are we building?\n");
        status.setText("Connected • new conversation");
    }

    private void sendMessage() {
        final String message = messageInput.getText().toString().trim();
        if (message.isEmpty() || apiKey.isEmpty()) return;

        messageInput.setText("");
        appendTranscript("\nYou: " + message + "\n\nQuill: …\n");
        sendButton.setEnabled(false);
        status.setText("Quill is thinking…");
        hideKeyboard();

        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("model", MODEL);
                body.put("instructions", INSTRUCTIONS);
                body.put("input", message);
                body.put("max_output_tokens", 1600);
                if (previousResponseId != null && !previousResponseId.isEmpty()) {
                    body.put("previous_response_id", previousResponseId);
                }

                HttpURLConnection conn = (HttpURLConnection) new URL(API_URL).openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(120000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                conn.setRequestProperty("Content-Type", "application/json");

                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(bytes);
                }

                int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                String raw = readAll(stream);

                if (code < 200 || code >= 300) {
                    throw new Exception(extractApiError(raw, code));
                }

                JSONObject response = new JSONObject(raw);
                previousResponseId = response.optString("id", previousResponseId);
                String reply = extractOutputText(response);
                if (reply == null || reply.trim().isEmpty()) reply = "I received the response, but no text was returned.";
                final String finalReply = reply.trim();

                runOnUiThread(() -> {
                    replaceThinking(finalReply);
                    status.setText("Connected • " + MODEL);
                    sendButton.setEnabled(true);
                    messageInput.requestFocus();
                });
            } catch (Exception e) {
                final String error = e.getMessage() == null ? e.toString() : e.getMessage();
                runOnUiThread(() -> {
                    replaceThinking("Connection error: " + error);
                    status.setText("Connection needs attention");
                    status.setTextColor(Color.rgb(255, 193, 7));
                    sendButton.setEnabled(true);
                });
            }
        }).start();
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private String extractOutputText(JSONObject response) {
        StringBuilder out = new StringBuilder();
        JSONArray output = response.optJSONArray("output");
        if (output == null) return response.optString("output_text", "");

        for (int i = 0; i < output.length(); i++) {
            JSONObject item = output.optJSONObject(i);
            if (item == null) continue;
            JSONArray content = item.optJSONArray("content");
            if (content == null) continue;
            for (int j = 0; j < content.length(); j++) {
                JSONObject c = content.optJSONObject(j);
                if (c == null) continue;
                String type = c.optString("type", "");
                if ("output_text".equals(type)) {
                    String text = c.optString("text", "");
                    if (!text.isEmpty()) {
                        if (out.length() > 0) out.append("\n");
                        out.append(text);
                    }
                }
            }
        }
        return out.toString();
    }

    private String extractApiError(String raw, int code) {
        try {
            JSONObject obj = new JSONObject(raw);
            JSONObject err = obj.optJSONObject("error");
            if (err != null) {
                String msg = err.optString("message", "");
                if (!msg.isEmpty()) return "API " + code + ": " + msg;
            }
        } catch (Exception ignored) { }
        return "API request failed with HTTP " + code;
    }

    private void appendTranscript(String text) {
        transcript.append(text);
        scrollToBottom();
    }

    private void replaceThinking(String reply) {
        String current = transcript.getText().toString();
        String marker = "Quill: …\n";
        int idx = current.lastIndexOf(marker);
        if (idx >= 0) {
            current = current.substring(0, idx) + "Quill: " + reply + "\n" + current.substring(idx + marker.length());
            transcript.setText(current);
        } else {
            transcript.append("\nQuill: " + reply + "\n");
        }
        scrollToBottom();
    }

    private void scrollToBottom() {
        transcriptScroll.post(() -> transcriptScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    protected void onDestroy() {
        apiKey = "";
        super.onDestroy();
    }
    private void showIntroSettings() {
        SharedPreferences prefs = getSharedPreferences(IntroActivity.PREFS, MODE_PRIVATE);
        boolean skip = prefs.getBoolean(IntroActivity.KEY_SKIP_INTRO, false);
        String[] items = new String[] {
                "Replay cinematic intro",
                skip ? "Play intro on startup" : "Always skip intro on startup"
        };

        new AlertDialog.Builder(this)
                .setTitle("WonderPresence Intro")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        Intent intent = new Intent(this, IntroActivity.class);
                        intent.putExtra("force_replay", true);
                        startActivity(intent);
                    } else {
                        prefs.edit().putBoolean(IntroActivity.KEY_SKIP_INTRO, !skip).apply();
                        Toast.makeText(this, !skip ? "Future intros will be skipped." : "Intro will play on startup.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

}
