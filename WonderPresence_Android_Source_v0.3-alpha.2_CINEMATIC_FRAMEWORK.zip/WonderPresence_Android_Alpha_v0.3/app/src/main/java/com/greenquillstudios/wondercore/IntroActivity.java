package com.greenquillstudios.wondercore;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class IntroActivity extends Activity {
    public static final String PREFS = "wonderpresence_prefs";
    public static final String KEY_INTRO_COMPLETED = "intro_completed";
    public static final String KEY_SKIP_INTRO = "skip_intro";

    private final Handler handler = new Handler();
    private SharedPreferences prefs;
    private LinearLayout root;
    private ImageView logo;
    private TextView eyebrow;
    private TextView headline;
    private TextView body;
    private Button skipButton;
    private Button enterButton;
    private Button futureSkipButton;
    private MediaPlayer voiceover;
    private boolean firstViewing;
    private boolean sequenceFinished = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        firstViewing = !prefs.getBoolean(KEY_INTRO_COMPLETED, false);

        if (prefs.getBoolean(KEY_SKIP_INTRO, false) && !getIntent().getBooleanExtra("force_replay", false)) {
            openMain();
            return;
        }

        buildUi();
        startCinematic();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private TextView makeText(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        v.setAlpha(0f);
        return v;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(34), dp(24), dp(28));
        root.setBackgroundColor(Color.rgb(3, 5, 13));

        skipButton = new Button(this);
        skipButton.setText("SKIP");
        skipButton.setVisibility(firstViewing ? View.GONE : View.VISIBLE);
        skipButton.setOnClickListener(v -> finishSequence(true));
        LinearLayout.LayoutParams skipParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        skipParams.gravity = Gravity.END;
        root.addView(skipButton, skipParams);

        LinearLayout stage = new LinearLayout(this);
        stage.setOrientation(LinearLayout.VERTICAL);
        stage.setGravity(Gravity.CENTER);

        logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setAlpha(0f);
        logo.setScaleX(0.82f);
        logo.setScaleY(0.82f);
        stage.addView(logo, new LinearLayout.LayoutParams(dp(168), dp(168)));

        eyebrow = makeText("WONDERVERSE ENTERPRISES", 14, Color.rgb(203, 170, 74));
        eyebrow.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams eyebrowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        eyebrowParams.setMargins(0, dp(22), 0, 0);
        stage.addView(eyebrow, eyebrowParams);

        headline = makeText("Every great journey begins\nwith a single choice.", 28, Color.WHITE);
        headline.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams headlineParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        headlineParams.setMargins(0, dp(18), 0, 0);
        stage.addView(headline, headlineParams);

        body = makeText("", 17, Color.rgb(204, 211, 224));
        body.setLineSpacing(0, 1.18f);
        LinearLayout.LayoutParams bodyParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bodyParams.setMargins(0, dp(24), 0, 0);
        stage.addView(body, bodyParams);

        root.addView(stage, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        enterButton = new Button(this);
        enterButton.setText("ENTER WONDERPRESENCE");
        enterButton.setVisibility(View.GONE);
        enterButton.setOnClickListener(v -> openMain());
        root.addView(enterButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        futureSkipButton = new Button(this);
        futureSkipButton.setText("SKIP INTRO ON FUTURE LAUNCHES");
        futureSkipButton.setVisibility(View.GONE);
        futureSkipButton.setOnClickListener(v -> {
            prefs.edit().putBoolean(KEY_SKIP_INTRO, true).apply();
            openMain();
        });
        LinearLayout.LayoutParams futureParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        futureParams.setMargins(0, dp(8), 0, 0);
        root.addView(futureSkipButton, futureParams);

        setContentView(root);
    }

    private void startCinematic() {
        playVoiceoverIfPresent();

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1300)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();

        handler.postDelayed(() -> fadeIn(eyebrow, 850), 900);
        handler.postDelayed(() -> fadeIn(headline, 1200), 1900);

        handler.postDelayed(() -> showBody(
                "Welcome to WonderVerse Enterprises,\nwhere imagination becomes reality,\nand ideas become worlds."), 5000);

        handler.postDelayed(() -> showBody(
                "Powered by WonderCore.\n\nWonderPresence is your creative companion —\nbuilt to help you imagine, create, build,\nand bring your stories to life."), 10000);

        handler.postDelayed(() -> showBody(
                "This is more than an application.\nIt's the foundation of a universe.\n\nA place where stories grow, ideas become adventures,\nand imagination has no limits."), 17500);

        handler.postDelayed(() -> {
            headline.animate().alpha(0f).setDuration(500).withEndAction(() -> {
                headline.setText("Welcome to WonderPresence.");
                headline.animate().alpha(1f).setDuration(900).start();
            }).start();
            showBody("Let's begin.");
        }, 25000);

        handler.postDelayed(() -> finishSequence(false), 29000);
    }

    private void playVoiceoverIfPresent() {
        int rawId = getResources().getIdentifier(
                "wonderpresence_intro_master_v1", "raw", getPackageName());
        if (rawId == 0) return;
        try {
            voiceover = MediaPlayer.create(this, rawId);
            if (voiceover != null) voiceover.start();
        } catch (Exception ignored) {
        }
    }

    private void fadeIn(View view, long duration) {
        view.animate().alpha(1f).setDuration(duration).start();
    }

    private void showBody(String text) {
        body.animate().alpha(0f).setDuration(350).withEndAction(() -> {
            body.setText(text);
            body.animate().alpha(1f).setDuration(700).start();
        }).start();
    }

    private void finishSequence(boolean skipped) {
        if (sequenceFinished) return;
        sequenceFinished = true;
        handler.removeCallbacksAndMessages(null);
        stopVoiceover();

        prefs.edit().putBoolean(KEY_INTRO_COMPLETED, true).apply();

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start();
        eyebrow.setAlpha(1f);
        headline.setText("Welcome to WonderPresence.");
        headline.setAlpha(1f);
        body.setText(skipped ? "Cinematic skipped." : "Let's begin.");
        body.setAlpha(1f);
        skipButton.setVisibility(View.GONE);
        enterButton.setVisibility(View.VISIBLE);
        futureSkipButton.setVisibility(View.VISIBLE);
    }

    private void openMain() {
        stopVoiceover();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void stopVoiceover() {
        if (voiceover != null) {
            try {
                if (voiceover.isPlaying()) voiceover.stop();
                voiceover.release();
            } catch (Exception ignored) {
            }
            voiceover = null;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopVoiceover();
        super.onDestroy();
    }
}
