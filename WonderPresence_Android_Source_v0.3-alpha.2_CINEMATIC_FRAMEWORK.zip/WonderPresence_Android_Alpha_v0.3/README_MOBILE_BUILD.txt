WONDERPRESENCE ALPHA — CANON 7.11

Goal: first actually conversational WonderPresence Android Alpha.

WHAT CHANGED FROM 7.10
- Replaces the static foundation screen with a working text-chat UI.
- Adds OpenAI Responses API connection over HTTPS.
- Uses GPT-5.6 Luna for the Alpha bridge.
- Holds the API key only in process memory; WonderPresence does not persist it to disk.
- Maintains thread continuity with previous_response_id until NEW CHAT or app restart.
- Adds a Quill/WonderPresence system instruction.
- Keeps the canonical WonderCore launcher icon and WonderCore Studios Android app label.
- Adds android.permission.INTERNET.
- Version: 0.3-alpha / versionCode 3.

IMPORTANT
This API Alpha is separate from the ChatGPT app/account. It does not automatically share ChatGPT Plus, this chat's history, saved memories, connector access, or subscription billing. The user supplies an OpenAI API key in the app at runtime. The key is cleared from the app's variable when the process is destroyed and is never written by WonderPresence to SharedPreferences/files.

REPOSITORY NOTE
The existing GitHub repository already contains an Android project at the repository root. Therefore merely uploading this ZIP while keeping the old workflow will NOT update the app: the old workflow chooses the root project first. For 7.11, either replace the repo root project with this package contents OR update .github/workflows/build-android.yml to prefer the newest WonderCore source ZIP.


WonderPresence Alpha 7.12
========================
Brand canon:
  Powered by WonderCore™
  Featuring WonderPresence™

Continuity canon:
  project.wonder is the machine-readable project checkpoint.
  PROJECT_STATUS.md is the human-readable fallback.

Build target:
  WonderPresence-Alpha-v0.3-debug.apk

Alpha note:
  This developer Alpha asks for an OpenAI API key at runtime. Production WonderPresence must replace this with a user-friendly service/authentication bridge so ordinary users never handle API keys.
