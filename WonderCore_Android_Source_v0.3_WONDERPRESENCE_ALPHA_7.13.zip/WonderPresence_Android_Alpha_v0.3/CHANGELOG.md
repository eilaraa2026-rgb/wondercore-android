# 7.13 — Build-readiness correction

- Removed stale GitHub Actions preference for Alpha 7.11.
- Aligned Build Doctor checks with WonderPresence Alpha branding and version.
- Advanced canonical project checkpoint to 7.13.

# Changelog

## 0.3-alpha.1 — checkpoint 7.12

- Canonized branding as **Powered by WonderCore™ / Featuring WonderPresence™**.
- Changed Android launcher label to **WonderPresence Alpha**.
- Replaced invalid/noncanonical Alpha model identifier with documented API model `gpt-5.1`.
- Added `project.wonder` continuity scaffold.
- Added `PROJECT_STATUS.md` so future sessions can resume without reconstructing chat history.
- Documented consumer-UX requirement to remove API-key handling from the eventual public experience.

## 0.3-alpha — checkpoint 7.11

- Added conversational text UI.
- Added Responses API connection and multi-turn response chaining.
- Kept API key in process memory only.
